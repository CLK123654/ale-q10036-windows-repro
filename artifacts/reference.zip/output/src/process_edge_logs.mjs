import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { createGunzip } from "node:zlib";
import { createHmac } from "node:crypto";
import { fileURLToPath } from "node:url";

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  if (cell.length > 0 || row.length > 0) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  if (rows.length === 0) return [];
  const headers = rows.shift();
  return rows.filter((values) => values.some((value) => value !== "")).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])),
  );
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvText(headers, rows) {
  return `${headers.join(",")}\n${rows
    .map((row) => headers.map((header) => csvCell(row[header])).join(","))
    .join("\n")}\n`;
}

function isoHour(timestamp) {
  const date = new Date(timestamp);
  date.setUTCMinutes(0, 0, 0);
  return date.toISOString().replace(".000Z", "Z");
}

function nearestRank(values, percentile) {
  const ordered = [...values].sort((left, right) => left - right);
  return ordered[Math.max(0, Math.ceil(percentile * ordered.length) - 1)];
}

function visitorKey(visitorId, policy) {
  return createHmac("sha256", policy.hmac_salt)
    .update(visitorId)
    .digest("hex")
    .slice(0, policy.hmac_truncate_hex);
}

function suppression(lineNo, eventId, reason, detail) {
  return { line_no: lineNo, event_id: eventId ?? "", reason, detail };
}

function chooseRoute(rawPath, routes) {
  const cleanPath = String(rawPath ?? "").split("?", 1)[0];
  for (const route of routes) {
    const matched = route.match_kind === "exact"
      ? cleanPath === route.match_value
      : route.match_kind === "regex" && new RegExp(route.match_value).test(cleanPath);
    if (matched) return { ...route, cleanPath };
  }
  return { cleanPath };
}

function suppressionFor(row, policy, consents, routes) {
  const occurred = Date.parse(row.occurred_at_utc);
  const reportStart = Date.parse(policy.report_start_utc);
  const reportEnd = Date.parse(policy.report_end_utc);
  if (!Number.isFinite(occurred) || occurred < reportStart || occurred >= reportEnd) {
    return suppression(
      row.line_no,
      row.event_id,
      "outside_report_window",
      `${row.occurred_at_utc} not in half-open report window`,
    );
  }

  const consent = consents.get(row.visitor_id);
  if (!consent || consent.allow_tracking !== "true") {
    return suppression(row.line_no, row.event_id, "consent_denied", "allow_tracking is not true");
  }
  if (consent.deletion_requested === "true") {
    return suppression(row.line_no, row.event_id, "deletion_requested", "visitor has deletion request");
  }
  if (
    occurred < Date.parse(consent.consent_start_utc)
    || occurred >= Date.parse(consent.consent_end_utc)
  ) {
    return suppression(row.line_no, row.event_id, "consent_expired", "event time outside consent window");
  }

  const route = chooseRoute(row.path, routes);
  if (!route.route_key) {
    return suppression(row.line_no, row.event_id, "route_unmatched", route.cleanPath);
  }
  const agent = String(row.user_agent ?? "").toLowerCase();
  const botToken = policy.bot_user_agent_substrings.find((token) => agent.includes(String(token).toLowerCase()));
  if (botToken) {
    return suppression(row.line_no, row.event_id, "bot_user_agent", String(row.user_agent ?? ""));
  }
  if (policy.bot_asn_denylist.includes(row.asn)) {
    return suppression(row.line_no, row.event_id, "bot_asn", String(row.asn ?? ""));
  }
  return { route };
}

function assignSessions(rows, gapSeconds) {
  const sessionState = new Map();
  for (const row of rows) {
    const previous = sessionState.get(row.visitor_key);
    const gap = previous ? (Date.parse(row.occurred_at_utc) - previous.lastTimestamp) / 1000 : Infinity;
    const sessionNumber = !previous ? 1 : previous.sessionNumber + (gap > gapSeconds ? 1 : 0);
    row.session_id = `${row.visitor_key}-s${String(sessionNumber).padStart(2, "0")}`;
    sessionState.set(row.visitor_key, {
      sessionNumber,
      lastTimestamp: Date.parse(row.occurred_at_utc),
    });
  }
}

function buildSessionInventory(rows) {
  const sessions = new Map();
  for (const row of rows) {
    const current = sessions.get(row.session_id);
    if (!current) {
      sessions.set(row.session_id, {
        session_id: row.session_id,
        visitor_key: row.visitor_key,
        first_event_utc: row.occurred_at_utc,
        last_event_utc: row.occurred_at_utc,
        event_count: 1,
      });
    } else {
      current.last_event_utc = row.occurred_at_utc;
      current.event_count += 1;
    }
  }
  return [...sessions.values()].sort((left, right) => left.session_id.localeCompare(right.session_id));
}

function buildMetrics(rows) {
  const groups = new Map();
  for (const row of rows) {
    const key = `${isoHour(row.occurred_at_utc)}\u0000${row.route_group}`;
    const current = groups.get(key) ?? {
      hour_utc: isoHour(row.occurred_at_utc),
      route_group: row.route_group,
      event_count: 0,
      sessions: new Set(),
      byte_sum: 0,
      status_5xx: 0,
      durations: [],
    };
    current.event_count += 1;
    current.sessions.add(row.session_id);
    current.byte_sum += row.bytes;
    current.status_5xx += row.status >= 500 && row.status < 600 ? 1 : 0;
    current.durations.push(row.duration_ms);
    groups.set(key, current);
  }
  return [...groups.values()]
    .sort((left, right) => left.hour_utc.localeCompare(right.hour_utc) || left.route_group.localeCompare(right.route_group))
    .map((row) => ({
      hour_utc: row.hour_utc,
      route_group: row.route_group,
      event_count: row.event_count,
      session_count: row.sessions.size,
      byte_sum: row.byte_sum,
      status_5xx: row.status_5xx,
      p95_duration_ms: nearestRank(row.durations, 0.95),
    }));
}

export async function run(inputRoot, outputRoot) {
  const policy = JSON.parse(fs.readFileSync(path.join(inputRoot, "policy/privacy_policy.json"), "utf8"));
  const consents = new Map(
    parseCsv(fs.readFileSync(path.join(inputRoot, "policy/consent_windows.csv"), "utf8"))
      .map((row) => [row.visitor_id, row]),
  );
  const routes = parseCsv(fs.readFileSync(path.join(inputRoot, "catalog/route_catalog.csv"), "utf8"));
  const latestByEvent = new Map();
  const suppressions = [];
  let rawLogLines = 0;
  let parsedJsonLines = 0;

  const lines = readline.createInterface({
    input: fs.createReadStream(path.join(inputRoot, "logs/edge_access.ndjson.gz")).pipe(createGunzip()),
    crlfDelay: Infinity,
  });
  for await (const line of lines) {
    rawLogLines += 1;
    if (line.trim() === "") continue;
    let row;
    try {
      row = JSON.parse(line);
      parsedJsonLines += 1;
    } catch {
      suppressions.push(suppression(rawLogLines, "", "malformed_json", "line is not valid JSON"));
      continue;
    }
    row.line_no = rawLogLines;
    const previous = latestByEvent.get(row.event_id);
    const replace = !previous
      || Date.parse(row.updated_at_utc) > Date.parse(previous.updated_at_utc)
      || (row.updated_at_utc === previous.updated_at_utc && row.line_no > previous.line_no);
    if (replace) {
      if (previous) {
        suppressions.push(suppression(
          previous.line_no,
          previous.event_id,
          "superseded_event_version",
          `kept newer line ${row.line_no}`,
        ));
      }
      latestByEvent.set(row.event_id, row);
    } else {
      suppressions.push(suppression(
        row.line_no,
        row.event_id,
        "superseded_event_version",
        `kept newer line ${previous.line_no}`,
      ));
    }
  }

  const accepted = [];
  for (const row of [...latestByEvent.values()].sort((left, right) => left.line_no - right.line_no)) {
    const decision = suppressionFor(row, policy, consents, routes);
    if (!decision.route) {
      suppressions.push(decision);
      continue;
    }
    accepted.push({
      event_id: row.event_id,
      occurred_at_utc: row.occurred_at_utc,
      visitor_key: visitorKey(row.visitor_id, policy),
      route_key: decision.route.route_key,
      route_group: decision.route.route_group,
      canonical_path: decision.route.canonical_path,
      status: Number(row.status),
      status_class: `${Math.floor(Number(row.status) / 100)}xx`,
      bytes: Number(row.bytes),
      duration_ms: Number(row.duration_ms),
      _line_no: row.line_no,
    });
  }
  accepted.sort((left, right) =>
    left.occurred_at_utc.localeCompare(right.occurred_at_utc)
      || left.event_id.localeCompare(right.event_id)
      || left._line_no - right._line_no,
  );
  assignSessions(accepted, Number(policy.session_gap_seconds));

  const normalized = accepted.map(({ _line_no, ...row }) => ({
    event_id: row.event_id,
    occurred_at_utc: row.occurred_at_utc,
    visitor_key: row.visitor_key,
    session_id: row.session_id,
    route_key: row.route_key,
    route_group: row.route_group,
    canonical_path: row.canonical_path,
    status: row.status,
    status_class: row.status_class,
    bytes: row.bytes,
    duration_ms: row.duration_ms,
  }));
  suppressions.sort((left, right) => left.line_no - right.line_no || left.reason.localeCompare(right.reason));
  const sessions = buildSessionInventory(normalized);
  const metrics = buildMetrics(normalized);
  const totalBytes = normalized.reduce((sum, row) => sum + row.bytes, 0);
  const status5xxTotal = normalized.filter((row) => row.status >= 500 && row.status < 600).length;
  const controls = {
    raw_log_lines: rawLogLines,
    parsed_json_lines: parsedJsonLines,
    accepted_event_count: normalized.length,
    suppression_count: suppressions.length,
    session_count: sessions.length,
    metric_rows: metrics.length,
    total_bytes: totalBytes,
    status_5xx_total: status5xxTotal,
  };
  const reportRoot = path.join(outputRoot, "reports");
  fs.mkdirSync(reportRoot, { recursive: true });
  fs.writeFileSync(
    path.join(reportRoot, "normalized_events.ndjson"),
    `${normalized.map((row) => JSON.stringify(row)).join("\n")}\n`,
  );
  fs.writeFileSync(
    path.join(reportRoot, "suppressed_lines.csv"),
    csvText(["line_no", "event_id", "reason", "detail"], suppressions),
  );
  fs.writeFileSync(
    path.join(reportRoot, "session_inventory.csv"),
    csvText(["session_id", "visitor_key", "first_event_utc", "last_event_utc", "event_count"], sessions),
  );
  fs.writeFileSync(
    path.join(reportRoot, "hourly_route_metrics.csv"),
    csvText(["hour_utc", "route_group", "event_count", "session_count", "byte_sum", "status_5xx", "p95_duration_ms"], metrics),
  );
  fs.writeFileSync(path.join(reportRoot, "run_summary.json"), `${JSON.stringify(controls, null, 2)}\n`);
  return { normalized, suppressions, sessions, metrics, controls };
}

const modulePath = fs.realpathSync(fileURLToPath(import.meta.url));
const invokedPath = process.argv[1] ? fs.realpathSync(process.argv[1]) : "";
if (modulePath === invokedPath) {
  const inputRoot = path.resolve(process.argv[2] ?? ".");
  const outputRoot = path.resolve(process.argv[3] ?? "output");
  run(inputRoot, outputRoot)
    .then(({ controls }) => {
      process.stdout.write(`${JSON.stringify(controls)}\n`);
    })
    .catch((error) => {
      process.stderr.write(`${error.stack ?? error}\n`);
      process.exitCode = 1;
    });
}
