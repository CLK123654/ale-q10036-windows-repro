[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [string]$InputRoot,
  [Parameter(Mandatory = $true)]
  [string]$OutputRoot
)

$ErrorActionPreference = 'Stop'
$required = @(
  'logs/edge_access.ndjson.gz',
  'policy/privacy_policy.json',
  'policy/consent_windows.csv',
  'catalog/route_catalog.csv'
)
foreach ($relative in $required) {
  if (-not (Test-Path -LiteralPath (Join-Path $InputRoot $relative) -PathType Leaf)) {
    throw "Missing required input: $relative"
  }
}

$scriptPath = Join-Path $PSScriptRoot 'src/process_edge_logs.mjs'
if (-not (Test-Path -LiteralPath $scriptPath -PathType Leaf)) {
  throw 'Missing Node.js entry file'
}

$resolvedOutput = [System.IO.Path]::GetFullPath($OutputRoot)
$reportRoot = Join-Path $resolvedOutput 'reports'
if (Test-Path -LiteralPath $reportRoot) {
  Remove-Item -LiteralPath $reportRoot -Recurse -Force
}
New-Item -ItemType Directory -Path $resolvedOutput -Force | Out-Null

& node $scriptPath ([System.IO.Path]::GetFullPath($InputRoot)) $resolvedOutput
if ($LASTEXITCODE -ne 0) {
  throw "Node.js process failed with exit code $LASTEXITCODE"
}
