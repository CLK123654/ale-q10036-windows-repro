import fs from 'node:fs/promises';

const source = await fs.readFile('logs/edge_access.ndjson.gz', 'utf8');
for (const line of source.split('\n')) {
  if (line.length === 0) continue;
  const event = JSON.parse(line);
  process.stdout.write(`${event.visitor_id},${event.path}\n`);
}
